package stepDefinitions;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;

import io.appium.java_client.android.AndroidDriver;

public class ScreenshotUtil {
	public static String captureScreenshot(AndroidDriver driver, String screenshotName) {
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String destination = System.getProperty("user.dir") + "/target/Screenshot/" + screenshotName + ".png";
			File finalDestination = new File(destination);
			FileHandler.copy(source, finalDestination);
			return destination;
		} catch (IOException e) {
			System.out.println("Exception while taking screenshot: " + e.getMessage());
			return null;
		}
	}
}
