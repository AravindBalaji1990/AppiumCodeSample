package stepDefinitions;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.junit.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.AutomationName;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class StepDefinitions {
	private static ExtentReports extent;
	static ExtentTest scenarioTest;
	private static ExtentSparkReporter sparkReporter;
	AndroidDriver driver;
	Scenario scenario;

	@Before
	public void setup() {
		// Initialize the ExtentReports and attach the reporter
		sparkReporter = new ExtentSparkReporter("target/ExtentReports.html");
		extent = new ExtentReports();
		extent.attachReporter(sparkReporter);
	}

	@BeforeStep
	public void beforeScenario(Scenario scenario) {
		// Create a test node in the report for each scenario
		scenarioTest = extent.createTest(scenario.getName());
	}

	@After
	public void afterScenario(Scenario scenario) {

		// Log the scenario outcome in the report
		if (scenario.isFailed()) {
			scenarioTest.fail("Scenario failed: " + scenario.getName());
		} else {
			scenarioTest.pass("Scenario passed: " + scenario.getName());
		}
		extent.flush();
		driver.quit();
	}

	@AfterStep
	public void tearDown(Scenario scenario) {
		String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "screenhot");

		if (screenshotPath != null) {
			scenarioTest.fail("Scenario failed: " + scenario.getName(),
					MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
		} else {
			scenarioTest.fail("Scenario failed: " + scenario.getName());
		}

	}

	@Given("a precondition")
	public void a_precondition() throws MalformedURLException, InterruptedException {
		scenarioTest.info("Executing precondition step");
		UiAutomator2Options options = new UiAutomator2Options();
		options.setPlatformName("Android");
		options.setDeviceName("29221JEGR00379");
		options.setAutomationName(AutomationName.ANDROID_UIAUTOMATOR2);
		options.setAppPackage("io.appium.android.apis");
		options.setAppActivity("io.appium.android.apis.ApiDemos");
		options.setAppWaitForLaunch(true);
		options.setAppWaitDuration(Duration.ofSeconds(60));

		// calling the andorid driver to run the app
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		Thread.sleep(3000);
	}

	@When("an action is performed")
	public void an_action_is_performed() {
		scenarioTest.info("Executing action step");
		Assert.assertTrue(driver
				.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"App\"]")).isDisplayed());
	}

	@Then("a result is verified")
	public void a_result_is_verified() {
		scenarioTest.info("Executing verification step");
		boolean verifyelement = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Action Bar\"]")).isDisplayed();
		scenarioTest.info("element verificaiton :" + verifyelement);

	}

}
