# paraminfoassignment

What is this project ?
Sauce lab applciation automation for mobile - Android/IOS .

What is requried?
Java 1.8 and greater
Maven
Eclipse
Cucumber
Selenium 
Appium - via node/desktop
reposrting is taken are by extent reporter

How to run ?
Just downlaod the code 
Build the application using maven build and update the maven if required.
Run from maven -> Right click pom.xml maven install or go to java file named TestRunner right click run as Junittest
